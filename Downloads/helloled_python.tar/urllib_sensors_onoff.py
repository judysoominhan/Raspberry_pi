from urllib.request import urlopen
import json

url = 'http://localhost:3020/api/sensors/v'

fp = urlopen(url)  # u is a file like object
data = fp.read() # bytearray
mystr = data.decode("utf8")
fp.close()
#print(mystr)

js = json.loads(mystr)
print(js['switch'] )